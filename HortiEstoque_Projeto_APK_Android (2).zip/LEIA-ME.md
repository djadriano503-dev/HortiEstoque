# HortiEstoque — projeto Android para gerar APK

Este projeto empacota o aplicativo de estoque em um app Android usando WebView local.
Inclui seleção de imagens da galeria para foto dos produtos e armazenamento local do navegador.

## Gerar APK pelo Android Studio
1. Instale o Android Studio e o Android SDK (API 35).
2. Extraia esta pasta.
3. No Android Studio, escolha **Open** e selecione a pasta `HortiEstoque_APK_Projeto`.
4. Aguarde a sincronização do Gradle.
5. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. O APK de teste será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

## Gerar APK na nuvem pelo GitHub Actions
1. Crie um repositório GitHub e envie todos os arquivos deste projeto.
2. Abra a aba **Actions** e execute **Build HortiEstoque APK** (ou faça push na branch main).
3. Baixe o artefato `HortiEstoque-apk` ao final da execução.
4. O arquivo `app-debug.apk` poderá ser instalado no Android habilitando a instalação de fontes permitidas.

## Observações
- Este é um APK de depuração para instalação direta e testes; para Play Store é necessário gerar uma versão release assinada.
- Os dados ficam no armazenamento local do app. Desinstalar o app pode apagar os dados; exporte relatórios periodicamente.
- O app não sincroniza dados entre aparelhos.
